def assemble(lines: list[str]) -> list[int]:
    """
    Simple one-pass translation of assembly language
    source code into instructions.  Empty lines and lines
    with only labels and comments are skipped.
    Handles *only* numerical offsets, not symbolic labels.
    For example:
        STORE   r1,r0,r15[8]    # OK, store value of r1 at location pc+8
        ADD/Z   r15,r0,r0[-3]   # OK, jump 3 steps back if zero is in condition code
    but not
        STORE   r1,variable     # cannot use symbolic address of variable
        JUMP/Z  again           # cannot use pseudo-instruction JUMP or symbolic label 'again'
    """
    error_count = 0
    instructions = [ ]
    for lnum in range(len(lines)):
        line = lines[lnum]
        log.debug(f"Processing line {lnum}: {line}")
        try: 
            fields = parse_line(line)
            if fields["kind"] == AsmSrcKind.FULL:
                log.debug("Constructing instruction")
                fill_defaults(fields)
                instr = instruction_from_dict(fields)
                word = instr.encode()
                instructions.append(word)
            elif fields["kind"] == AsmSrcKind.DATA:
                word = value_parse(fields["value"])
                instructions.append(word)
            else:
                log.debug(f"No instruction on line {lnum}: {line}")
        except SyntaxError as e:
            error_count += 1
            print(f"Syntax error in line {lnum}: {line}", file=sys.stderr)
        except KeyError as e:
            error_count += 1
            print(f"Unknown word in line {lnum}: {e}", file=sys.stderr)
        except Exception as e:
            error_count += 1
            print(f"Exception encountered in line {lnum}: {e}", file=sys.stderr)
        if error_count > ERROR_LIMIT:
            print("Too many errors; abandoning", file=sys.stderr)
            sys.exit(1)
    return instructions

def main(sourcefile: io.IOBase, objfile: io.IOBase):
    """"Assemble a Duck Machine program"""
    lines = sourcefile.readlines()
    object_code = assemble(lines)
    log.debug(f"Object code: \n{object_code}")
    for word in object_code:
        log.debug(f"Instruction word {word}")
        print(word,file=objfile)

if __name__ == "__main__":
    args = cli()
    main(args.sourcefile, args.objfile)