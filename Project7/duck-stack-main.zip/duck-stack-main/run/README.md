# The 'run' folder

This folder contains scripts for running the full set of 
duck machine project applications together, potentially
compiling, assembling, and running a Mallard program.